
##################################################
# Output으로 값 확인
##################################################

output "aws_account_id" {
  description = "현재 연결된 AWS 계정 ID"
  value       = data.aws_caller_identity.current.account_id
}

output "aws_user_arn" {
  description = "현재 사용하는 IAM 사용자 또는 IAM 역할 ARN"
  value       = data.aws_caller_identity.current.arn
}

output "aws_region" {
  description = "현재 AWS Provider 리전"
  value       = data.aws_region.current.name
}


