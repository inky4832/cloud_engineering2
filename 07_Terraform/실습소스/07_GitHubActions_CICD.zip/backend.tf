##################################################
# Terraform Backend
##################################################

terraform {

  backend "s3" {

    bucket = "terraform-state-inky4832-tu07pldn"

    key = "terraform/project1/terraform.tfstate"

    region = "ap-northeast-2"

    encrypt = true

    use_lockfile = true

  }

}