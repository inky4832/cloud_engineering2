##################################################
# VPC
##################################################

resource "aws_vpc" "terraform_vpc_inky4832" {

  cidr_block = "10.50.0.0/16"

  enable_dns_support = true

  enable_dns_hostnames = true

  tags = {
    Name = "terraform-vpc-inky4832"
  }

}