##################################################
# Output
##################################################

output "vpc_id" {

  description = "생성된 VPC ID"

  value = aws_vpc.terraform_vpc_inky4832.id

}