output "type_conversion_functions" {
  value = {
    tostring_result = tostring(
      100
    )

    tonumber_result = tonumber(
      "100"
    )

    tolist_result = tolist([
      "web",
      "database"
    ])

    toset_result = toset([
      "dev",
      "prod",
      "dev"
    ])

    tomap_result = tomap({
      dev  = "t3.micro"
      prod = "t3.medium"
    })
  }
}