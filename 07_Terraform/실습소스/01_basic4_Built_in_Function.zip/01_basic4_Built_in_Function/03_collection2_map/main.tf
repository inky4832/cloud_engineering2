locals {
  instance_types = {
    dev  = "t3.micro"
    prod = "t3.medium"
  }

  common_tags = {
    Project   = "terraform"
    ManagedBy = "Terraform"
  }

  environment_tags = {
    Environment = "dev"
    ManagedBy   = "IaC"
  }
}

output "map_functions" {
  value = {
    lookup_result = lookup(
      local.instance_types,
      "dev",
      "t3.small"
    )

    merge_result = merge(
      local.common_tags,
      local.environment_tags
    )

    keys_result = keys(
      local.instance_types
    )

    values_result = values(
      local.instance_types
    )
  }
}