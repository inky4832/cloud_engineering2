locals {
  public_subnets = [
    "public-a",
    "public-c"
  ]

  private_subnets = [
    "private-a",
    "private-c"
  ]

  environments = [
    "dev",
    "prod",
    "dev"
  ]
}

output "list_functions" {
  value = {
    length_result = length(
      local.public_subnets
    )

    contains_result = contains(
      local.environments,
      "prod"
    )

    concat_result = concat(
      local.public_subnets,
      local.private_subnets
    )

    distinct_result = distinct(
      local.environments
    )

    sort_result = sort([
      "redis",
      "web",
      "database"
    ])
  }
}