locals {
  project     = "terraform"
  environment = "dev"
}

output "string_functions" {
  value = {
    upper_result = upper(local.project)

    lower_result = lower("TERRAFORM")

    format_result = format(
      "%s-%s-vpc",
      local.project,
      local.environment
    )

    join_result = join(
      "-",
      ["terraform", "aws", "eks"]
    )

    split_result = split(
      "-",
      "terraform-aws-eks"
    )

    replace_result = replace(
      "terraform-dev-vpc",
      "dev",
      "prod"
    )
  }
}