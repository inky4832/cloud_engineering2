output "number_functions" {
  value = {
    max_result = max(
      10,
      20,
      30
    )

    min_result = min(
      10,
      20,
      30
    )

    ceil_result = ceil(
      3.2
    )

    floor_result = floor(
      3.2
    )

    pow_result = pow(
      2,
      3
    )
  }
}