locals {
  environment       = "dev"
  allowed_instances = ["t3.micro", "t3.small"]
}

output "boolean_functions" {
  value = {
    contains_result = contains(
      local.allowed_instances,
      "t3.micro"
    )

    startswith_result = startswith(
      "terraform-study",
      "terraform"
    )

    endswith_result = endswith(
      "terraform-study",
      "study"
    )

    can_result = can(
      tonumber("100")
    )
  }
}