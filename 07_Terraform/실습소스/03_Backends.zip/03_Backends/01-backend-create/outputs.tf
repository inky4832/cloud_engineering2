##################################################
# Terraform Outputs
##################################################

# 생성된 Backend용 S3 Bucket 이름을 출력한다.
output "terraform_state_bucket_name" {
  description = "Terraform Backend에 사용할 S3 Bucket 이름"
  value       = aws_s3_bucket.terraform_state.bucket
}