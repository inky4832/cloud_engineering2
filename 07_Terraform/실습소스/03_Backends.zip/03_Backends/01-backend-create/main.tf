##################################################
# Random String
##################################################

# S3 Bucket 이름을 고유하게 만들기 위한
# 8자리 랜덤 문자열을 생성한다.
resource "random_string" "bucket_suffix" {
  length  = 8
  special = false
  upper   = false
}


##################################################
# Terraform State S3 Bucket
##################################################

# Terraform State 파일을 저장할
# 전용 S3 Bucket을 생성한다.
resource "aws_s3_bucket" "terraform_state" {
  bucket = "terraform-state-inky4832-${random_string.bucket_suffix.result}"

  tags = {
    Name      = "terraform-state-inky4832"
    Purpose   = "Terraform Backend"
    ManagedBy = "Terraform"
  }
}


##################################################
# S3 Public Access Block
##################################################

# Terraform State 파일이 외부에 공개되지 않도록
# 모든 Public Access를 차단한다.
resource "aws_s3_bucket_public_access_block" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}


##################################################
# S3 Versioning
##################################################

# State 파일이 변경되거나 삭제되었을 때
# 이전 버전으로 복구할 수 있도록 설정한다.
resource "aws_s3_bucket_versioning" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id

  versioning_configuration {
    status = "Enabled"
  }
}


##################################################
# S3 Server-Side Encryption
##################################################

# S3에 저장되는 State 파일을
# AES256 방식으로 암호화한다.
resource "aws_s3_bucket_server_side_encryption_configuration" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}