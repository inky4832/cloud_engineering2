##################################################
# Terraform S3 Backend
##################################################

terraform {
  backend "s3" {
    bucket       = "terraform-state-inky4832-uyv0ui98"
    key          = "backend-lab/terraform.tfstate"
    region       = "ap-northeast-2"
    encrypt      = true
    use_lockfile = true
  }
}