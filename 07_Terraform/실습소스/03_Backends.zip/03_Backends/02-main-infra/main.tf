##################################################
# Backend Test S3 Bucket
##################################################

# Local Backend와 S3 Backend 동작을
# 확인하기 위한 실습용 S3 Bucket이다.
resource "aws_s3_bucket" "backend_test" {
  bucket_prefix = "terraform-backend-test-inky4832-"

  tags = {
    Name        = "terraform-backend-test"
    Environment = "Practice"
    ManagedBy   = "Terraform"
    # Test = "S3-Backend"
  }
}


##################################################
# S3 Public Access Block
##################################################

# 실습용 S3 Bucket이 외부에
# 공개되지 않도록 설정한다.
resource "aws_s3_bucket_public_access_block" "backend_test" {
  bucket = aws_s3_bucket.backend_test.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}