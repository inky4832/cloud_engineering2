##################################################
# Terraform Outputs
##################################################

# 실습용 S3 Bucket 이름을 출력한다.
output "test_bucket_name" {
  description = "Backend 실습용 S3 Bucket 이름"
  value       = aws_s3_bucket.backend_test.bucket
}