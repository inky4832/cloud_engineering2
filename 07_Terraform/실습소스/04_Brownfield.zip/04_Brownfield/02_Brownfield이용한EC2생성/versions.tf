##################################################
# Terraform Version
##################################################

terraform {

  # Terraform 버전을 제한.
  required_version = ">= 1.8.0"

  # Terraform이 사용할 Provider를 정의
  required_providers {

    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.100"  # version = "~> 5.30"
    }

  }
}