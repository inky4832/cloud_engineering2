##################################################
# 기존 VPC 조회
#
# AWS에 이미 생성되어 있는 VPC를
# Name 태그를 기준으로 조회
##################################################

data "aws_vpc" "existing_vpc_inky4832" {

  filter {

    name = "tag:Name"

    values = [
      "terraform-vpc-inky4832"
    ]

  }

}

##################################################
# 기존 Public Subnet 조회
#
# AWS에 이미 생성되어 있는
# Public Subnet 1을 Name 태그로 조회
##################################################

data "aws_subnet" "existing_public_subnet1_inky4832" {

  filter {

    name = "tag:Name"

    values = [
      "public-subnet1-inky4832"
    ]

  }

  filter {

    name = "vpc-id"

    values = [
      data.aws_vpc.existing_vpc_inky4832.id
    ]

  }

}

##################################################
# Amazon Linux 2023 AMI 조회
##################################################

data "aws_ami" "amazon_linux_2023" {

  most_recent = true

  owners = [
    "amazon"
  ]

  filter {

    name = "name"

    values = [
      "al2023-ami-2023.*-x86_64"
    ]

  }

  filter {

    name = "virtualization-type"

    values = [
      "hvm"
    ]

  }

}

##################################################
# EC2 Security Group 생성
#
# 기존 VPC 내부에 Security Group 생성
##################################################

resource "aws_security_group" "ec2_security_group_inky4832" {

  name = "ec2-security-group-inky4832"

  description = "Security Group for Brownfield EC2"

  vpc_id = data.aws_vpc.existing_vpc_inky4832.id

  ##################################################
  # SSH 접속 허용
  #
  # 실습용으로 전체 IP 허용
  # 운영 환경에서는 관리자 IP만 허용 권장
  ##################################################

  ingress {

    description = "SSH"

    from_port = 22

    to_port = 22

    protocol = "tcp"

    cidr_blocks = [
      "0.0.0.0/0"
    ]

  }

  ##################################################
  # 외부 통신 허용
  ##################################################

  egress {

    from_port = 0

    to_port = 0

    protocol = "-1"

    cidr_blocks = [
      "0.0.0.0/0"
    ]

  }

  tags = {

    Name = "ec2-security-group-inky4832"

  }

}

##################################################
# EC2 생성
#
# 기존 VPC의 기존 Public Subnet에 EC2 생성
##################################################

resource "aws_instance" "brownfield_ec2_inky4832" {

  ami = data.aws_ami.amazon_linux_2023.id

  instance_type = "t3.micro"

  subnet_id = data.aws_subnet.existing_public_subnet1_inky4832.id

  vpc_security_group_ids = [

    aws_security_group.ec2_security_group_inky4832.id

  ]

  associate_public_ip_address = true

  tags = {

    Name = "brownfield-ec2-inky4832"

  }

}
