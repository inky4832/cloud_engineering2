##################################################
# EC2 Public IP 출력
##################################################

output "ec2_public_ip" {

  description = "EC2 Public IP"

  value = aws_instance.brownfield_ec2_inky4832.public_ip

}

##################################################
# 기존 VPC ID 출력
##################################################

output "existing_vpc_id" {

  description = "Existing VPC ID"

  value = data.aws_vpc.existing_vpc_inky4832.id

}

##################################################
# 기존 Public Subnet ID 출력
##################################################

output "existing_public_subnet_id" {

  description = "Existing Public Subnet ID"

  value = data.aws_subnet.existing_public_subnet1_inky4832.id

}