##################################################
# Terraform Version
##################################################

terraform {

  # Terraform 버전을 제한.
  required_version = ">= 1.8.0"

  # Terraform이 사용할 Provider를 정의
  required_providers {

    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.100"
    }

  }
}

##################################################
# AWS Provider
##################################################
provider "aws" {

  region = "ap-northeast-2"

}


##################################################
# VPC 생성
##################################################

resource "aws_vpc" "terraform_vpc_inky4832" {

  cidr_block = "10.50.0.0/16"

  enable_dns_support = true

  enable_dns_hostnames = true

  tags = {
    Name = "terraform-vpc-inky4832"
  }

}