##################################################
# Terraform Version
##################################################

terraform {

  # Terraform 버전을 제한.
  required_version = ">= 1.8.0"

  # Terraform이 사용할 Provider를 정의
  required_providers {

    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.100"
    }

  }
}

##################################################
# AWS Provider
##################################################
provider "aws" {

  region = "ap-northeast-2"

}


##################################################
# VPC 생성
##################################################

resource "aws_vpc" "terraform_vpc_inky4832" {

  cidr_block = "10.50.0.0/16"

  enable_dns_support = true

  enable_dns_hostnames = true

  tags = {
    Name = "terraform-vpc-inky4832"
  }

}

##################################################
# Subnet 연결
##################################################

 resource "aws_subnet" "public-inky4832" { 
  vpc_id = aws_vpc.terraform_vpc_inky4832.id 
  cidr_block = "10.50.1.0/24" 
  tags = { 
      Name = "public-subnet-inky4832" 
  } 

  # depends_on = [ aws_vpc.terraform_vpc_inky4832 ]

}

##################################################
# EC2 생성 
##################################################

resource "aws_instance" "terraform_ec2_inky4832" {

  for_each ={
    web = "t3.micro" 
    api = "t3.small"
  }

  ami           = "ami-0e4ab31f1847c850c"  # Ubuntu Server 24.04 LTS
  instance_type = each.value



  subnet_id = aws_subnet.public-inky4832.id

  tags = {
    Name = "${each.key}-terraform-ec2-inky4832"
  }
}