##################################################
# 기존 EC2(Resource 선언)
#
# 아직 생성하는 것이 아니라
# Import할 대상을 선언하는 것
##################################################

# resource "aws_instance" "my_ec2" {

# }

##################################################
# 기존 EC2(Resource)
##################################################

resource "aws_instance" "my_ec2" {

  ami = "ami-0ae6acc9dcb61caa3"

  instance_type = "t3.micro"

  subnet_id = "subnet-0e3a746dc23c879cb"

  vpc_security_group_ids = [

    "sg-0796aed659ffe5a63"

  ]

  tags = {

    Name = "my-ec2-inky4832"

  }

}