##################################################
# 문자열/숫자/리스트/맵  작성하기
##################################################

locals {
  
  # 문자열 값
  project_name = "terraform-practice"

  # 숫자 값
  instance_count = 2

  # Boolean 값
  enable_monitoring = true

  # List
  availability_zones = [
    "ap-northeast-2a",
    "ap-northeast-2c"
  ]

  # Map
  common_tags = {
    Project     = "terraform-practice"
    Environment = "dev"
    ManagedBy   = "Terraform"
  }

  common_tags2 = {
    Project2 : "terraform-practice2"
    Environment2 : "dev2"
    ManagedBy2 : "Terraform2"
  }

}
