##################################################
#  input variable  
#  명령어: 
#   terraform apply  -var="instance_type=t3.large" 
##################################################

variable "instance_type" {

  type = string
  default = "t3.micro"
}