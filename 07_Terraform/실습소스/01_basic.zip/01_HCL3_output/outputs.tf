
##################################################
# Output으로 값 확인
##################################################

output "project_name" {
  value = local.project_name
}

output "resource_name" {
  value = local.resource_name
}

output "first_availability_zone" {
  value = local.availability_zones[0]
}

output "environment_tag" {
  value = local.common_tags["Environment"]
  sensitive = true
}
