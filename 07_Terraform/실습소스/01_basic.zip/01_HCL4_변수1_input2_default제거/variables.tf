##################################################
#  input variable  
##################################################

variable "project_name" {

  description = "프로젝트 이름"
  type = string
  # default = "terraform-study"

}

variable "environment" {

  default = "dev"

}