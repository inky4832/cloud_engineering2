##################################################
#  local variable  
##################################################

locals {

  project = "bank"

  environment = "dev"

  region = "ap-northeast-2"

}