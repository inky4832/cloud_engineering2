
##################################################
# Output으로 값 확인
##################################################

output "project" {

  value = local.project

}

output "environment" {

  value = local.environment

}

output "region" {

  value = local.region

}
