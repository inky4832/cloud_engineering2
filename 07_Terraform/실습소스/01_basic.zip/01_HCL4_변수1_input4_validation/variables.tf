##################################################
#  input variable  
#  명령어: 
#   terraform apply  -var="instance_type=t3.large" 
##################################################

variable "instance_type" {

  type = string

  validation {

    condition = contains(

      ["t3.micro","t3.small","t3.medium"],

      var.instance_type

    )
    error_message = "지원하지 않는 Instance Type 입니다."

  }

}