##################################################
#  input variable  
#  명령어
#  terraform apply -var-file="prod.tfvars
##################################################

variable "instance_type" {

  type = string
  default = "t3.micro"
}