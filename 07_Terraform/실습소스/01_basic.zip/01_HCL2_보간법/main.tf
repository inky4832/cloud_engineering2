##################################################
# 문자열 조합하기
##################################################

locals {
  
  # 문자열
  project_name = "terraform"

  # 실행 환경
  environment = "dev"

  # 숫자
  instance_count = 2

  # Boolean
  enable_monitoring = true

  # List
  availability_zones = [
    "ap-northeast-2a",
    "ap-northeast-2c"
  ]

  # Map
  common_tags = {
    Project     = local.project_name
    Environment = local.environment
    ManagedBy   = "Terraform"
  }

  # 문자열 조합
  resource_name = "${local.project_name}-${local.environment}-vpc"
}