##################################################
#  input variable  
##################################################

variable "project" {

  default = "banking"

}

variable "environment" {

  default = "dev"

}