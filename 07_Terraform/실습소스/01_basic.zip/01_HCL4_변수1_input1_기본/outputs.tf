
##################################################
# Output으로 값 확인
##################################################

output "project_name" {
  value = var.project_name
}


output "environment_name" {
  value = var.environment
  sensitive = true
}
