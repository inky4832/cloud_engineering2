##################################################
# EC2 Module
##################################################

module "ec2" {

  source = "./modules/ec2_X"

  ami           = "ami-0e4ab31f1847c850c"  # Ubuntu Server 24.04 LTS

  instance_type = "t3.micro"

  subnet_id = "subnet-0e3a746dc23c879cb"

  security_group_id = "sg-0796aed659ffe5a63"

  name = "my-ec2-inky4832"

}

##################################################
# Output
##################################################

output "instance_id" {

  value = module.ec2.instance_id

}