
##################################################
# VPC Module
##################################################

module "vpc" {

  source = "./modules/vpc"
}

##################################################
# EC2 Module
##################################################

module "ec2" {

  source = "./modules/ec2_X"

  ami           = "ami-0e4ab31f1847c850c"  # Ubuntu Server 24.04 LTS

  instance_type = "t3.micro"

  subnet_id = module.vpc.subnet_id                     # "subnet-0e3a746dc23c879cb"

  security_group_id =  module.vpc.security_group_id    # "sg-0796aed659ffe5a63"

  name = "my-ec2-inky4832"

}

##################################################
# Output
##################################################

output "instance_id" {

  value = module.ec2.instance_id

}
##################################################
# VPC ID Output
##################################################

output "vpc_id" {

  value = module.vpc.vpc_id

}

##################################################
# Subnet ID Output
##################################################

output "subnet_id" {

  value = module.vpc.subnet_id

}

##################################################
# Security Group ID Output
##################################################

output "security_group_id" {

  value = module.vpc.security_group_id

}
