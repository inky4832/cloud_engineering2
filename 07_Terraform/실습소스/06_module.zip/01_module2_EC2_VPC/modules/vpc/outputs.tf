##################################################
# VPC ID Output
##################################################

output "vpc_id" {

  value = aws_vpc.my_vpc.id

}

##################################################
# Subnet ID Output
##################################################

output "subnet_id" {

  value = aws_subnet.my_subnet.id

}

##################################################
# Security Group ID Output
##################################################

output "security_group_id" {

  value = aws_security_group.my_sg.id

}