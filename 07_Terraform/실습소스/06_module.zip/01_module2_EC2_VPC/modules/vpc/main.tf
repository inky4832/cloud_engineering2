##################################################
# VPC(Resource)
##################################################

resource "aws_vpc" "my_vpc" {

  cidr_block = "10.50.0.0/16"

  enable_dns_support = true

  enable_dns_hostnames = true

  tags = {

    Name = "terraform-vpc-inky4832"

  }

}

##################################################
# Subnet(Resource)
##################################################

resource "aws_subnet" "my_subnet" {

  vpc_id = aws_vpc.my_vpc.id

  cidr_block = "10.50.1.0/24"

  availability_zone = "ap-northeast-2a"

  map_public_ip_on_launch = true

  tags = {

    Name = "terraform-subnet-inky4832"

  }

}

##################################################
# Security Group(Resource)
##################################################

resource "aws_security_group" "my_sg" {

  name = "terraform-sg-inky4832"

  description = "Allow SSH"

  vpc_id = aws_vpc.my_vpc.id

  ingress {

    from_port = 22

    to_port = 22

    protocol = "tcp"

    cidr_blocks = [

      "0.0.0.0/0"

    ]

  }

  egress {

    from_port = 0

    to_port = 0

    protocol = "-1"

    cidr_blocks = [

      "0.0.0.0/0"

    ]

  }

  tags = {

    Name = "terraform-sg-inky4832"

  }

}