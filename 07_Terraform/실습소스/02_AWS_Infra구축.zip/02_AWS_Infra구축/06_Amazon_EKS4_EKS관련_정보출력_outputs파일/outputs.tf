##################################################
# EKS Cluster 이름 출력
##################################################

output "eks_cluster_name" {

  description = "EKS Cluster Name"

  value = aws_eks_cluster.eks_cluster_inky4832.name

}

##################################################
# EKS Cluster API Endpoint 출력
##################################################

output "eks_cluster_endpoint" {

  description = "EKS Cluster API Endpoint"

  value = aws_eks_cluster.eks_cluster_inky4832.endpoint

}

##################################################
# EKS Cluster 인증서 정보 출력
#
# Kubernetes Client가 EKS API Server의
# 인증서를 확인할 때 사용하는 정보이다.
##################################################

output "eks_cluster_certificate_authority" {

  description = "EKS Cluster Certificate Authority Data"

  value = aws_eks_cluster.eks_cluster_inky4832.certificate_authority[0].data

  sensitive = true

}

##################################################
# ECR Repository URL 출력
##################################################

output "ecr_repository_url" {

  description = "Amazon ECR Repository URL"

  value = aws_ecr_repository.ecr_repository_inky4832.repository_url

}

##################################################
# RDS Endpoint 출력
##################################################

output "rds_endpoint" {

  description = "MySQL RDS Endpoint"

  value = aws_db_instance.mysql_rds_inky4832.endpoint

}

##################################################
# RDS 주소만 출력
#
# endpoint에는 포트 번호가 포함될 수 있고
# address는 호스트 주소만 출력한다.
##################################################

output "rds_address" {

  description = "MySQL RDS Address"

  value = aws_db_instance.mysql_rds_inky4832.address

}