##################################################
# RDS 데이터베이스 이름
##################################################

variable "db_name" {

  description = "RDS MySQL Database Name"

  type = string

  default = "testdb"

}

##################################################
# RDS 관리자 계정
##################################################

variable "db_username" {

  description = "RDS MySQL Administrator Username"

  type = string

  default = "admin"

}

##################################################
# RDS 관리자 비밀번호
#
# sensitive = true
# Terraform 실행 결과에 비밀번호가
# 직접 표시되지 않도록 설정한다.
##################################################

variable "db_password" {

  description = "RDS MySQL Administrator Password"

  type = string

  sensitive = true

}