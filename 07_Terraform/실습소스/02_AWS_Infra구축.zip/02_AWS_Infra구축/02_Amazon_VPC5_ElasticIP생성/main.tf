##################################################
# Terraform Version
##################################################

terraform {

  required_version = ">= 1.8.0"

  required_providers {

    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.100"
    }

  }

}

##################################################
# AWS Provider
##################################################

provider "aws" {

  region = "ap-northeast-2"

}

##################################################
# VPC 생성
##################################################

resource "aws_vpc" "terraform_vpc_inky4832" {

  cidr_block = "10.50.0.0/16"

  enable_dns_support = true

  enable_dns_hostnames = true

  tags = {

    Name = "terraform-vpc-inky4832"

    Environment = "Practice"

    Project = "Terraform"

    Owner = "inky4832"

  }

}

##################################################
# Public Subnet 1
# 인터넷과 통신 가능한 Public Subnet
# 이후 ALB가 생성될 Subnet
##################################################
resource "aws_subnet" "public_subnet1_inky4832" {

  # 어느 VPC에 생성할 것인지 지정
  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  # Subnet의 IP 대역
  cidr_block = "10.50.10.0/24"

  # 가용영역(AZ)
  availability_zone = "ap-northeast-2a"

  # EC2 생성 시 Public IP 자동 할당
  map_public_ip_on_launch = true

  tags = {
    Name = "public-subnet1-inky4832"
  }
}

##################################################
# Public Subnet 2
# ALB의 이중화를 위해 두 번째 AZ에 생성
##################################################
resource "aws_subnet" "public_subnet2_inky4832" {

  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  cidr_block = "10.50.20.0/24"

  availability_zone = "ap-northeast-2c"

  map_public_ip_on_launch = true

  tags = {
    Name = "public-subnet2-inky4832"
  }
}


##################################################
# Private Subnet 1
# EKS Worker Node와 RDS가 생성될 Private Subnet
# 외부에서는 직접 접근할 수 없음
##################################################

resource "aws_subnet" "private_subnet1_inky4832" {

  # 앞에서 생성한 VPC에 Subnet 생성
  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  # Private Subnet CIDR
  cidr_block = "10.50.30.0/24"

  # 첫 번째 가용영역
  availability_zone = "ap-northeast-2a"

  # Public IP 자동 할당 비활성화
  map_public_ip_on_launch = false

  tags = {

    Name = "private-subnet1-inky4832"

  }

}

##################################################
# Private Subnet 2
# 고가용성을 위해 두 번째 AZ에 생성
##################################################

resource "aws_subnet" "private_subnet2_inky4832" {

  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  cidr_block = "10.50.40.0/24"

  availability_zone = "ap-northeast-2c"

  map_public_ip_on_launch = false

  tags = {

    Name = "private-subnet2-inky4832"

  }

}

##################################################
# Internet Gateway 생성
#
# VPC와 인터넷을 연결하는 Gateway
# Public Subnet이 인터넷과 통신하기 위해 반드시 필요
##################################################

resource "aws_internet_gateway" "internet_gateway_inky4832" {

  # 앞에서 생성한 VPC에 Internet Gateway 연결
  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  # AWS Console에 표시할 이름
  tags = {
    Name = "internet-gateway-inky4832"
  }

}

##################################################
# Public Route Table 생성
#
# Public Subnet에서 외부 인터넷으로 나가는 경로를 관리
# 0.0.0.0/0 트래픽을 Internet Gateway로 전달
##################################################

resource "aws_route_table" "public_route_table_inky4832" {

  # 앞에서 생성한 VPC 내부에 Route Table 생성
  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  ##################################################
  # 인터넷으로 나가는 기본 경로
  #
  # 0.0.0.0/0
  # └── 모든 IPv4 목적지를 의미
  #
  # gateway_id
  # └── 앞에서 생성한 Internet Gateway의 ID를 참조
  ##################################################
  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.internet_gateway_inky4832.id
  }

  # AWS Console에 표시할 이름
  tags = {
    Name = "public-route-table-inky4832"
  }
}


##################################################
# Public Subnet 1 ↔ Public Route Table 연결
#
# Public Subnet 1이 Public Route Table을 사용하도록 설정
##################################################

resource "aws_route_table_association" "public_subnet1_association_inky4832" {

  # 연결할 Public Subnet
  subnet_id = aws_subnet.public_subnet1_inky4832.id

  # 연결할 Public Route Table
  route_table_id = aws_route_table.public_route_table_inky4832.id

}

##################################################
# Public Subnet 2 ↔ Public Route Table 연결
#
# Public Subnet 2가 Public Route Table을 사용하도록 설정
##################################################

resource "aws_route_table_association" "public_subnet2_association_inky4832" {

  # 연결할 Public Subnet
  subnet_id = aws_subnet.public_subnet2_inky4832.id

  # 연결할 Public Route Table
  route_table_id = aws_route_table.public_route_table_inky4832.id

}


##################################################
# Elastic IP 생성
#
# NAT Gateway에서 사용할 고정 Public IP 생성
#
# Elastic IP는 AWS에서 제공하는 고정 공인 IP이다.
# NAT Gateway 생성 시 반드시 필요하다.
##################################################

resource "aws_eip" "elastic_ip_inky4832" {

  # VPC에서 사용할 Elastic IP
  domain = "vpc"

  # AWS Console에 표시할 이름
  tags = {

    Name = "elastic-ip-inky4832"

  }

}