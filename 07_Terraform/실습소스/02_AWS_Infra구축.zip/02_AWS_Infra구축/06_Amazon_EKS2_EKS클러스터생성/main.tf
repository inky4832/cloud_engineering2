##################################################
# Terraform Version
##################################################

terraform {

  required_version = ">= 1.8.0"

  required_providers {

    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.100"
    }

  }

}

##################################################
# AWS Provider
##################################################

provider "aws" {

  region = "ap-northeast-2"

}

##################################################
# VPC 생성
##################################################

resource "aws_vpc" "terraform_vpc_inky4832" {

  cidr_block = "10.50.0.0/16"

  enable_dns_support = true

  enable_dns_hostnames = true

  tags = {

    Name = "terraform-vpc-inky4832"

    Environment = "Practice"

    Project = "Terraform"

    Owner = "inky4832"

  }

}

##################################################
# Public Subnet 1
# 인터넷과 통신 가능한 Public Subnet
# 이후 ALB가 생성될 Subnet
##################################################
resource "aws_subnet" "public_subnet1_inky4832" {

  # 어느 VPC에 생성할 것인지 지정
  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  # Subnet의 IP 대역
  cidr_block = "10.50.10.0/24"

  # 가용영역(AZ)
  availability_zone = "ap-northeast-2a"

  # EC2 생성 시 Public IP 자동 할당
  map_public_ip_on_launch = true

  tags = {
    Name = "public-subnet1-inky4832"
  }
}

##################################################
# Public Subnet 2
# ALB의 이중화를 위해 두 번째 AZ에 생성
##################################################
resource "aws_subnet" "public_subnet2_inky4832" {

  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  cidr_block = "10.50.20.0/24"

  availability_zone = "ap-northeast-2c"

  map_public_ip_on_launch = true

  tags = {
    Name = "public-subnet2-inky4832"
  }
}


##################################################
# Private Subnet 1
# EKS Worker Node와 RDS가 생성될 Private Subnet
# 외부에서는 직접 접근할 수 없음
##################################################

resource "aws_subnet" "private_subnet1_inky4832" {

  # 앞에서 생성한 VPC에 Subnet 생성
  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  # Private Subnet CIDR
  cidr_block = "10.50.30.0/24"

  # 첫 번째 가용영역
  availability_zone = "ap-northeast-2a"

  # Public IP 자동 할당 비활성화
  map_public_ip_on_launch = false

  tags = {

    Name = "private-subnet1-inky4832"

  }

}

##################################################
# Private Subnet 2
# 고가용성을 위해 두 번째 AZ에 생성
##################################################

resource "aws_subnet" "private_subnet2_inky4832" {

  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  cidr_block = "10.50.40.0/24"

  availability_zone = "ap-northeast-2c"

  map_public_ip_on_launch = false

  tags = {

    Name = "private-subnet2-inky4832"

  }

}

##################################################
# Internet Gateway 생성
#
# VPC와 인터넷을 연결하는 Gateway
# Public Subnet이 인터넷과 통신하기 위해 반드시 필요
##################################################

resource "aws_internet_gateway" "internet_gateway_inky4832" {

  # 앞에서 생성한 VPC에 Internet Gateway 연결
  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  # AWS Console에 표시할 이름
  tags = {
    Name = "internet-gateway-inky4832"
  }

}

##################################################
# Public Route Table 생성
#
# Public Subnet에서 외부 인터넷으로 나가는 경로를 관리
# 0.0.0.0/0 트래픽을 Internet Gateway로 전달
##################################################

resource "aws_route_table" "public_route_table_inky4832" {

  # 앞에서 생성한 VPC 내부에 Route Table 생성
  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  ##################################################
  # 인터넷으로 나가는 기본 경로
  #
  # 0.0.0.0/0
  # └── 모든 IPv4 목적지를 의미
  #
  # gateway_id
  # └── 앞에서 생성한 Internet Gateway의 ID를 참조
  ##################################################
  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.internet_gateway_inky4832.id
  }

  # AWS Console에 표시할 이름
  tags = {
    Name = "public-route-table-inky4832"
  }
}


##################################################
# Public Subnet 1 ↔ Public Route Table 연결
#
# Public Subnet 1이 Public Route Table을 사용하도록 설정
##################################################

resource "aws_route_table_association" "public_subnet1_association_inky4832" {

  # 연결할 Public Subnet
  subnet_id = aws_subnet.public_subnet1_inky4832.id

  # 연결할 Public Route Table
  route_table_id = aws_route_table.public_route_table_inky4832.id

}

##################################################
# Public Subnet 2 ↔ Public Route Table 연결
#
# Public Subnet 2가 Public Route Table을 사용하도록 설정
##################################################

resource "aws_route_table_association" "public_subnet2_association_inky4832" {

  # 연결할 Public Subnet
  subnet_id = aws_subnet.public_subnet2_inky4832.id

  # 연결할 Public Route Table
  route_table_id = aws_route_table.public_route_table_inky4832.id

}


##################################################
# Elastic IP 생성
#
# NAT Gateway에서 사용할 고정 Public IP 생성
#
# Elastic IP는 AWS에서 제공하는 고정 공인 IP이다.
# NAT Gateway 생성 시 반드시 필요하다.
##################################################

resource "aws_eip" "elastic_ip_inky4832" {

  # VPC에서 사용할 Elastic IP
  domain = "vpc"

  # AWS Console에 표시할 이름
  tags = {

    Name = "elastic-ip-inky4832"

  }

}


##################################################
# NAT Gateway 생성
#
# Private Subnet에서 인터넷으로 나가기 위한 Gateway
#
# ※ 반드시 Public Subnet에 생성해야 한다.
##################################################

resource "aws_nat_gateway" "nat_gateway_inky4832" {

  ##################################################
  # 앞에서 생성한 Elastic IP를 NAT Gateway에 연결
  ##################################################
  allocation_id = aws_eip.elastic_ip_inky4832.id

  ##################################################
  # Public Subnet 1에 NAT Gateway 생성
  ##################################################
  subnet_id = aws_subnet.public_subnet1_inky4832.id

  ##################################################
  # AWS Console에 표시할 이름
  ##################################################
  tags = {

    Name = "nat-gateway-inky4832"

  }

  ##################################################
  # Internet Gateway 생성 후 NAT Gateway 생성
  #
  # depends_on을 사용하지 않아도 대부분 생성되지만,
  # 생성 순서를 명확하게 지정하기 위해 추가
  ##################################################
  depends_on = [
    aws_internet_gateway.internet_gateway_inky4832
  ]

}

##################################################
# Private Route Table 생성
#
# Private Subnet에서 외부 인터넷으로 나가는 경로를 관리
#
# Internet Gateway가 아닌 NAT Gateway를 사용한다.
##################################################

resource "aws_route_table" "private_route_table_inky4832" {

  ##################################################
  # 앞에서 생성한 VPC 내부에 Route Table 생성
  ##################################################
  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  ##################################################
  # 인터넷으로 나가는 기본 경로
  #
  # 목적지 : 모든 외부 네트워크
  # 대상   : NAT Gateway
  ##################################################
  route {

    cidr_block = "0.0.0.0/0"

    nat_gateway_id = aws_nat_gateway.nat_gateway_inky4832.id

  }

  ##################################################
  # AWS Console에 표시할 이름
  ##################################################
  tags = {

    Name = "private-route-table-inky4832"

  }

}

##################################################
# Private Subnet 1 ↔ Private Route Table 연결
#
# Private Subnet 1이 Private Route Table을 사용하도록 설정
##################################################

resource "aws_route_table_association" "private_subnet1_association_inky4832" {

  # 연결할 Private Subnet 1의 ID
  subnet_id = aws_subnet.private_subnet1_inky4832.id

  # 앞에서 생성한 Private Route Table의 ID
  route_table_id = aws_route_table.private_route_table_inky4832.id
}

##################################################
# Private Subnet 2 ↔ Private Route Table 연결
#
# Private Subnet 2도 동일한 Private Route Table을 사용하도록 설정
##################################################

resource "aws_route_table_association" "private_subnet2_association_inky4832" {

  # 연결할 Private Subnet 2의 ID
  subnet_id = aws_subnet.private_subnet2_inky4832.id

  # 앞에서 생성한 Private Route Table의 ID
  route_table_id = aws_route_table.private_route_table_inky4832.id
}

##################################################
# RDS Security Group 생성
#
# MySQL(3306) 접근을 허용하는 Security Group
#
# 현재는 실습을 위해 모든 IP 접근 허용
# 이후 EC2/EKS Security Group만 허용하도록 변경 예정
##################################################

resource "aws_security_group" "rds_security_group_inky4832" {

  ##################################################
  # Security Group이 생성될 VPC
  ##################################################
  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  ##################################################
  # Security Group 이름
  ##################################################
  name = "rds-security-group-inky4832"

  description = "RDS Security Group"

  ##################################################
  # Inbound Rule
  #
  # MySQL(3306) 접근 허용
  ##################################################
  ingress {

    # 시작 포트
    from_port = 3306

    # 종료 포트
    to_port = 3306

    # TCP 프로토콜 사용
    protocol = "tcp"

    # 모든 IP 허용 (실습용)
    cidr_blocks = ["0.0.0.0/0"]

  }

  ##################################################
  # Outbound Rule
  #
  # 모든 외부 통신 허용
  ##################################################
  egress {

    from_port = 0

    to_port = 0

    protocol = "-1"

    cidr_blocks = ["0.0.0.0/0"]

  }

  ##################################################
  # AWS Console에 표시될 이름
  ##################################################
  tags = {

    Name = "rds-security-group-inky4832"

  }

}


##################################################
# EKS Worker Node Security Group 생성
#
# EKS Worker Node(EC2)가 사용할 Security Group
#
# 현재는 실습을 위해 모든 통신 허용
# 이후 필요한 Rule만 남길 예정
##################################################

resource "aws_security_group" "eks_node_security_group_inky4832" {

  ##################################################
  # Security Group이 생성될 VPC
  ##################################################
  vpc_id = aws_vpc.terraform_vpc_inky4832.id

  ##################################################
  # Security Group 이름
  ##################################################
  name = "eks-node-security-group-inky4832"

  description = "EKS Worker Node Security Group"

  ##################################################
  # Inbound Rule
  #
  # 실습을 위해 모든 통신 허용
  ##################################################
  ingress {

    from_port = 0

    to_port = 0

    protocol = "-1"

    cidr_blocks = ["0.0.0.0/0"]

  }

  ##################################################
  # Outbound Rule
  #
  # 모든 외부 통신 허용
  ##################################################
  egress {

    from_port = 0

    to_port = 0

    protocol = "-1"

    cidr_blocks = ["0.0.0.0/0"]

  }

  ##################################################
  # AWS Console에 표시될 이름
  ##################################################
  tags = {

    Name = "eks-node-security-group-inky4832"

  }

}

##################################################
# Amazon ECR Repository 생성
#
# Docker Image를 저장하는 Repository
#
# GitHub Actions가 Docker Image를 Push하고
# EKS가 해당 이미지를 Pull하여 Pod를 생성한다.
##################################################

resource "aws_ecr_repository" "ecr_repository_inky4832" {

  ##################################################
  # Repository 이름
  #
  # GitHub Actions와 Kubernetes에서
  # 동일한 Repository 이름을 사용해야 한다.
  ##################################################
  name = "kube-ecr-inky4832"

  ##################################################
  # Image Tag 중복 허용
  #
  # MUTABLE
  #   같은 Tag(latest 등)를 덮어쓸 수 있다.
  #
  # IMMUTABLE
  #   같은 Tag를 다시 사용할 수 없다.
  ##################################################
  image_tag_mutability = "MUTABLE"

  ##################################################
  # 이미지 삭제 시 자동 삭제
  #
  # terraform destroy 실행 시
  # Repository 안의 이미지도 함께 삭제된다.
  ##################################################
  force_delete = true

  ##################################################
  # 이미지 업로드(Push) 시
  # 자동으로 취약점 스캔 수행
  ##################################################
  image_scanning_configuration {

    scan_on_push = true

  }

  ##################################################
  # Repository 암호화
  #
  # AES256 : AWS 기본 암호화 방식
  ##################################################
  encryption_configuration {

    encryption_type = "AES256"

  }

  ##################################################
  # AWS Console에서 표시될 이름
  ##################################################
  tags = {

    Name = "kube-ecr-inky4832"

  }

}


##################################################
# DB Subnet Group 생성
#
# RDS가 사용할 Subnet을 지정한다.
#
# 일반적으로 Private Subnet 2개 이상을 등록한다.
##################################################

resource "aws_db_subnet_group" "db_subnet_group_inky4832" {

  ##################################################
  # DB Subnet Group 이름
  ##################################################
  name = "db-subnet-group-inky4832"

  ##################################################
  # RDS가 사용할 Private Subnet 지정
  ##################################################
  subnet_ids = [

    aws_subnet.private_subnet1_inky4832.id,

    aws_subnet.private_subnet2_inky4832.id

  ]

  ##################################################
  # AWS Console에 표시될 이름
  ##################################################
  tags = {

    Name = "db-subnet-group-inky4832"

  }

}



##################################################
# MySQL RDS 생성
#
# Spring Boot 애플리케이션에서 사용할
# MySQL 데이터베이스를 생성한다.
##################################################

resource "aws_db_instance" "mysql_rds_inky4832" {

  ##################################################
  # RDS 식별자
  #
  # AWS Console에서 RDS 인스턴스를 구분할 때 사용
  ##################################################
  identifier = "mysql-rds-inky4832"

  ##################################################
  # 데이터베이스 엔진
  ##################################################
  engine = "mysql"

  ##################################################
  # MySQL 엔진 버전
  #
  # 특정 버전을 고정하면 AWS에서 지원이 종료되거나
  # 계정 및 리전에 따라 생성이 실패할 수 있다.
  #
  # 실습에서는 AWS가 지원하는 기본 MySQL 8.0 계열을
  # 사용하도록 engine_version을 생략할 수 있다.
  ##################################################
  engine_version = "8.4.9"

  ##################################################
  # RDS 인스턴스 크기
  #
  # 실습용 소형 인스턴스
  ##################################################
  instance_class = "db.t3.micro"

  ##################################################
  # 초기 스토리지 용량
  #
  # 단위 : GiB
  ##################################################
  allocated_storage = 20

  ##################################################
  # 스토리지 유형
  #
  # gp3 : 범용 SSD
  ##################################################
  storage_type = "gp3"

  ##################################################
  # 데이터베이스 이름
  #
  # variables.tf에 선언한 값을 사용
  ##################################################
  db_name = var.db_name

  ##################################################
  # 관리자 계정과 비밀번호
  ##################################################
  username = var.db_username

  password = var.db_password

  ##################################################
  # MySQL 기본 포트
  ##################################################
  port = 3306

  ##################################################
  # 앞에서 생성한 DB Subnet Group 연결
  #
  # RDS가 Private Subnet 1 또는
  # Private Subnet 2에 생성된다.
  ##################################################
  db_subnet_group_name = aws_db_subnet_group.db_subnet_group_inky4832.name

  ##################################################
  # 앞에서 생성한 RDS Security Group 연결
  ##################################################
  vpc_security_group_ids = [

    aws_security_group.rds_security_group_inky4832.id

  ]

  ##################################################
  # Public Access 비활성화
  #
  # 인터넷에서 RDS Endpoint로
  # 직접 접속하지 못하도록 설정
  ##################################################
  publicly_accessible = false

  ##################################################
  # Multi-AZ 비활성화
  #
  # 실습 비용 절감을 위해 단일 AZ 사용
  ##################################################
  multi_az = false

  ##################################################
  # 스토리지 암호화 활성화
  ##################################################
  storage_encrypted = true

  ##################################################
  # 자동 스토리지 확장
  #
  # 데이터가 증가하면 최대 30GiB까지
  # 자동으로 스토리지를 확장할 수 있다.
  ##################################################
  max_allocated_storage = 30

  ##################################################
  # 자동 백업 보존 기간
  #
  # 0 : 자동 백업 비활성화
  #
  # 실습 비용과 삭제 편의를 위해 0으로 설정
  ##################################################
  backup_retention_period = 0

  ##################################################
  # 삭제 방지 기능 비활성화
  #
  # true로 설정하면 실수로 삭제하는 것을 방지하지만
  # terraform destroy도 제한된다.
  ##################################################
  deletion_protection = false

  ##################################################
  # Terraform 삭제 시 최종 Snapshot 생략
  #
  # 실습 종료 후 terraform destroy를
  # 바로 실행할 수 있도록 설정
  ##################################################
  skip_final_snapshot = true

  ##################################################
  # Terraform 변경으로 RDS를 교체할 때
  # 기존 Snapshot을 생성하지 않는다.
  ##################################################
  delete_automated_backups = true

  ##################################################
  # 마이너 버전 자동 업그레이드
  ##################################################
  auto_minor_version_upgrade = true

  ##################################################
  # AWS Console에 표시될 이름
  ##################################################
  tags = {

    Name = "mysql-rds-inky4832"

  }

}


##################################################
# EKS Cluster IAM Role 생성
#
# EKS Control Plane이 AWS 서비스를 사용할 때
# 필요한 권한을 부여하는 IAM Role
##################################################

resource "aws_iam_role" "eks_cluster_role_inky4832" {

  ##################################################
  # IAM Role 이름
  ##################################################
  name = "eks-cluster-role-inky4832"

  ##################################################
  # 신뢰 정책(Trust Policy)
  #
  # EKS 서비스가 이 IAM Role을
  # 사용할 수 있도록 허용한다.
  ##################################################
  assume_role_policy = jsonencode({

    Version = "2012-10-17"

    Statement = [

      {

        Effect = "Allow"

        Principal = {

          Service = "eks.amazonaws.com"

        }

        Action = "sts:AssumeRole"

      }

    ]

  })

  ##################################################
  # AWS Console에 표시될 이름
  ##################################################
  tags = {

    Name = "eks-cluster-role-inky4832"

  }

}

##################################################
# EKS Cluster IAM Policy 연결
#
# 앞에서 생성한 EKS Cluster Role에
# AmazonEKSClusterPolicy를 연결한다.
##################################################

resource "aws_iam_role_policy_attachment" "eks_cluster_policy_attachment_inky4832" {

  ##################################################
  # 정책을 연결할 IAM Role
  ##################################################
  role = aws_iam_role.eks_cluster_role_inky4832.name

  ##################################################
  # AWS 관리형 EKS Cluster 정책
  ##################################################
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSClusterPolicy"

}



##################################################
# EKS Node Group IAM Role 생성
#
# EKS Worker Node로 실행되는 EC2 인스턴스가
# 사용할 IAM Role
##################################################

resource "aws_iam_role" "eks_node_group_role_inky4832" {

  ##################################################
  # IAM Role 이름
  ##################################################
  name = "eks-node-group-role-inky4832"

  ##################################################
  # 신뢰 정책(Trust Policy)
  #
  # Worker Node는 EC2 인스턴스이므로
  # EC2 서비스가 이 Role을 사용하도록 허용한다.
  ##################################################
  assume_role_policy = jsonencode({

    Version = "2012-10-17"

    Statement = [

      {

        Effect = "Allow"

        Principal = {

          Service = "ec2.amazonaws.com"

        }

        Action = "sts:AssumeRole"

      }

    ]

  })

  ##################################################
  # AWS Console에 표시될 이름
  ##################################################
  tags = {

    Name = "eks-node-group-role-inky4832"

  }

}



##################################################
# EKS Worker Node Policy 연결
#
# Worker Node가 EKS Cluster에 연결하고
# Cluster 정보를 조회할 수 있도록 허용한다.
##################################################

resource "aws_iam_role_policy_attachment" "eks_worker_node_policy_attachment_inky4832" {

  ##################################################
  # 정책을 연결할 Node Group IAM Role
  ##################################################
  role = aws_iam_role.eks_node_group_role_inky4832.name

  ##################################################
  # AWS 관리형 Worker Node 정책
  ##################################################
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy"

}


##################################################
# ECR Image Pull Policy 연결
#
# Worker Node가 Amazon ECR에서
# Docker Image를 다운로드할 수 있도록 허용한다.
##################################################

resource "aws_iam_role_policy_attachment" "ecr_pull_policy_attachment_inky4832" {

  ##################################################
  # 정책을 연결할 Node Group IAM Role
  ##################################################
  role = aws_iam_role.eks_node_group_role_inky4832.name

  ##################################################
  # ECR Image Pull 전용 AWS 관리형 정책
  ##################################################
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryPullOnly"

}


##################################################
# Amazon VPC CNI Policy 연결
#
# EKS Pod에 VPC IP 주소를 할당하고
# 네트워크 인터페이스를 관리할 수 있도록 허용한다.
##################################################

resource "aws_iam_role_policy_attachment" "eks_cni_policy_attachment_inky4832" {

  ##################################################
  # 정책을 연결할 Node Group IAM Role
  ##################################################
  role = aws_iam_role.eks_node_group_role_inky4832.name

  ##################################################
  # AWS 관리형 VPC CNI 정책
  ##################################################
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy"

}


##################################################
# Amazon EKS Cluster 생성
#
# Kubernetes Control Plane을 생성한다.
##################################################

resource "aws_eks_cluster" "eks_cluster_inky4832" {

  ##################################################
  # EKS Cluster 이름
  ##################################################
  name = "kube-cluster-inky4832"

  ##################################################
  # Kubernetes 버전
  #
  # 실습 시점에서 지원되는 버전 사용
  ##################################################
  version = "1.33"

  ##################################################
  # 앞에서 생성한 EKS Cluster IAM Role 연결
  ##################################################
  role_arn = aws_iam_role.eks_cluster_role_inky4832.arn

  ##################################################
  # EKS가 사용할 Subnet
  #
  # Worker Node는 이후 Private Subnet에 생성된다.
  ##################################################
  vpc_config {

    subnet_ids = [

      aws_subnet.public_subnet1_inky4832.id,
      aws_subnet.public_subnet2_inky4832.id,
      aws_subnet.private_subnet1_inky4832.id,
      aws_subnet.private_subnet2_inky4832.id

    ]

    ##################################################
    # Kubernetes API Endpoint
    #
    # 실습에서는 Public API 활성화
    ##################################################
    endpoint_public_access = true

    ##################################################
    # Private API 비활성화
    ##################################################
    endpoint_private_access = false

  }

  ##################################################
  # IAM Policy 연결 후 Cluster 생성
  ##################################################
  depends_on = [

    aws_iam_role_policy_attachment.eks_cluster_policy_attachment_inky4832

  ]

  ##################################################
  # AWS Console에 표시될 이름
  ##################################################
  tags = {

    Name = "kube-cluster-inky4832"

  }

}