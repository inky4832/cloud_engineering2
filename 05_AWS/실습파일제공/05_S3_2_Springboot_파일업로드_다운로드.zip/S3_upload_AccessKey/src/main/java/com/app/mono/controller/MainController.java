package com.app.mono.controller;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.app.mono.dto.UploadDTO;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

@Controller
public class MainController {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private final S3Client s3Client;
    private final String bucketName;

    public MainController(S3Client s3Client,
                          @Value("${aws.s3.bucket}") String bucketName) {
        this.s3Client = s3Client;
        this.bucketName = bucketName;
    }

    @GetMapping("/upload")
    public String main() {
        logger.info("logger: {}", "MainController.main()");
        return "uploadForm";
    }

    @PostMapping("/upload")
    public String upload(UploadDTO dto, Model m) {

        String theText = dto.getTheText();
        MultipartFile theFile = dto.getTheFile();

        long size = theFile.getSize();
        String name = theFile.getName();
        String originalFilename = theFile.getOriginalFilename();
        String contentType = theFile.getContentType();

        logger.info("theText={}", theText);
        logger.info("name={}", name);
        logger.info("originalFilename={}", originalFilename);
        logger.info("contentType={}", contentType);
        logger.info("size={}", size);

        String key = "images/" + originalFilename;

        try (InputStream inputStream = theFile.getInputStream()) {

            PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                    .bucket(bucketName)
                    .key(key)
                    .contentType(contentType)
                    .contentLength(size)
                    .build();

            s3Client.putObject(
                    putObjectRequest,
                    RequestBody.fromInputStream(inputStream, size)
            );

        } catch (IOException e) {
            throw new RuntimeException("S3 업로드 중 오류 발생", e);
        }

        // 업로드한 이미지 랜더링 위한 S3 객체 URL
        String url = "https://s3.ap-northeast-2.amazonaws.com/" + bucketName + "/" + key;
        m.addAttribute("url", url);

        // 다운로드용 key
        m.addAttribute("key", key);

        return "uploadInfo";
    }

    @GetMapping("/download")
    public @ResponseBody void download(@RequestParam String key,
                                       HttpServletResponse response) throws Exception {

        GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                .bucket(bucketName)
                .key(key)
                .build();

        try (ResponseInputStream<GetObjectResponse> is = s3Client.getObject(getObjectRequest);
             ServletOutputStream out = response.getOutputStream()) {

            String fileName = key.contains("/") ? key.substring(key.lastIndexOf("/") + 1) : key;

            byte[] buffer = new byte[4096];

            String sMimeType = is.response().contentType();
            if (sMimeType == null || sMimeType.isBlank()) {
                sMimeType = "application/octet-stream";
            }

            response.setContentType(sMimeType);

            String encodedFileName = URLEncoder.encode(fileName, StandardCharsets.UTF_8)
                    .replaceAll("\\+", "%20");

            response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + encodedFileName + "\"");

            int numRead;
            while ((numRead = is.read(buffer)) != -1) {
                out.write(buffer, 0, numRead);
            }

            out.flush();
        }
    }
}